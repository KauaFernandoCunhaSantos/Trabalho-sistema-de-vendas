import { AppBar, Box, Button, IconButton, Toolbar, Typography } from "@mui/material";
import StoreIcon from '@mui/icons-material/Store';
import { Link } from "react-router";
//import { useNavigate } from "react-router";

export default function Menu(){


    return<>
    <Box sx={{flexGrow:1, justifyContent:"space-around"}}>
    <AppBar position="static" color="warning">
        <Toolbar sx={{ display: "flex", justifyContent: "space-between", pr: "10vh" }}>
            
            <Box sx={{display:"flex", flexDirection:"row"}}>
            <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{mr:2}}
            >
                <StoreIcon/>
            </IconButton>
            <Typography variant="h4"  component="div" > Sistema vendas</Typography>
            
            <Button color="inherit" variant="text" size="large"   component={Link} to={"/Clientes"}>Clientes</Button>
            <Button color="inherit" variant="text" size="large"  component={Link} to={"/Produtos"}>Produtos</Button>
            <Button color="inherit" variant="text" size="large" component={Link} to={"/Vendas"}>Vendas</Button>
            </Box>
            <Button color="inherit" variant="text" size="large">LogOut</Button>
            
        </Toolbar>
    </AppBar>
    </Box>
    </>
}