import { Route, Routes } from "react-router"
import Menu from "../menu/Menu"
import Clientes from "../../pages/clientes/index.jsx"
import Produtos from "../../pages/produtos/index.jsx"
import Vendas from "../../pages/vendas/index.jsx"
import Home from "../../pages/home/index.jsx"
export default function Principal(){
    return<><Menu/>
    <Routes>
        <Route index element={<Home/>}/>
        <Route path="/Clientes" element={<Clientes/>}/>
        <Route path="/Produtos" element={<Produtos/>}/>
        <Route path="/Vendas" element={<Vendas/>}/>
                
    </Routes>
    </>
}